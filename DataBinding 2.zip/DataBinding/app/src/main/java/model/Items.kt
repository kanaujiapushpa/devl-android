package model


class Items(title: String?, description: String?, image: Int, price: Int, num_ratings: Int, serial_number: Int) {

    var mTitle: String? = title
    var description: String? = description
    var image: Int = image
    var price: Int = price
    var num_ratings: Int = num_ratings
    var serial_number: Int = serial_number

}
