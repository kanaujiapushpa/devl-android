package ui.activity.fragment

import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.pushpa.databinding.databinding.FragmentHomeBinding
import ui.activity.adapter.ItemAdapter
import viewModel.ItemViewModel

class ItemListFragment : android.support.v4.app.Fragment() {

    //data binding
    lateinit var mBinding: FragmentHomeBinding;
    lateinit var mContext: Context

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mContext = context!!
    }

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        mBinding = FragmentHomeBinding.inflate(inflater)
        var itemViewModel: ItemViewModel = ViewModelProviders.of(this).get(ItemViewModel::class.java!!)
        mBinding.itemViewModel = itemViewModel
        // mBinding.listOfItems=itemViewModel.itemList
        mBinding.myAdapter = ItemAdapter(itemViewModel.itemList, mContext)
        return mBinding.root
    }

}