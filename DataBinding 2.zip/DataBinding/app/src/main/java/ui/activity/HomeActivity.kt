package ui.activity

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.pushpa.databinding.R
import com.example.pushpa.databinding.databinding.ActivityHomeBinding
import ui.activity.fragment.ItemListFragment
import viewModel.ItemViewModel

public class HomeActivity : AppCompatActivity() {

    //data binding
    lateinit var mBinding: ActivityHomeBinding;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_home)
        val itemViewModel = ViewModelProviders.of(this).get(ItemViewModel::class.java!!)
        mBinding.itemViewModel = itemViewModel
        initComponent()
    }

    fun initComponent() {

        supportFragmentManager
                .beginTransaction()
                .add(R.id.fl_container, ItemListFragment(), "ItemListFragment")
                .commit()

    }

}