package ui.activity.adapter

import android.content.Context
import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.pushpa.databinding.R
import com.example.pushpa.databinding.databinding.ListItemBinding
import model.Items


class ItemAdapter(dataModelList: List<Items>, context: Context) : RecyclerView.Adapter<ItemAdapter.BindingHolder>() {

    var mContext: Context = context;
    var itemList: List<Items> = dataModelList

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindingHolder {
        var binding: ListItemBinding = DataBindingUtil.inflate(LayoutInflater.from(mContext), R.layout.list_item, parent, false)
        binding.testUrl = "https://i.redd.it/g5acbfi5hkm01.jpg"
        return BindingHolder(binding.root)
    }


    override fun onBindViewHolder(holder: BindingHolder, position: Int) {
        holder.binding.item = itemList[position]
        holder.binding.executePendingBindings()
    }

    override fun getItemCount(): Int {
        return itemList.size
    }


    class BindingHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var binding: ListItemBinding = DataBindingUtil.bind(itemView)!!
    }
}