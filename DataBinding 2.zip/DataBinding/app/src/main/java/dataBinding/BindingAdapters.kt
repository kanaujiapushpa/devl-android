package dataBinding


import android.databinding.BindingAdapter

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.pushpa.databinding.R
import android.graphics.drawable.Drawable
import android.support.annotation.NonNull

import android.support.annotation.Nullable


class BindingAdapters {
//
//    @BindingAdapter("android:setList")
//    fun setItemList(view: RecyclerView, model: ItemViewModel) {
////        var lm: RecyclerView.LayoutManager = view.layoutManager
////        view.adapter = ItemAdapter(view.context, model.itemList)
//    }


    @BindingAdapter("imageUrl")
   public fun setImage(view: ImageView, url: String) {
        var options: RequestOptions = RequestOptions().placeholder(R.drawable.ic_android_black_24dp)
        Glide.with(view.context).applyDefaultRequestOptions(options).load(url)

    }

    @BindingAdapter(value = ["imageUrl", "errorDrawable"], requireAll = false)
    fun loadImageWithError(imageView: ImageView,
                           @Nullable url: String?, @Nullable error: Drawable?) {
        if (url != null) {
            var options: RequestOptions = RequestOptions().placeholder(R.drawable.ic_android_black_24dp)
            Glide.with(imageView.context).applyDefaultRequestOptions(options).load("")
        } else if (error != null) {
            imageView.setImageDrawable(error)
        }
    }
}