package viewModel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import android.arch.lifecycle.ViewModel
import model.Items
import java.math.BigDecimal

class ItemViewModel : ViewModel() {
    val itemListLiveData: LiveData<ArrayList<Items>> = MutableLiveData<ArrayList<Items>>()


    val itemList: ArrayList<Items> = java.util.ArrayList()

    private val _likes = MutableLiveData<Int>()

    var itemA: Items = Items("Anuouk", "Womeen printed kurta", 0, 1000, 4, 1111);
    var itemB: Items = Items("Moda Rapido", "Rounded neck Tshirt", 0, 800, 4, 1111);
    var itemC: Items = Items("Levies", "Rounded neck Tshirt", 0, 1500, 4, 1111);
    var itemD: Items = Items("Mast and Harboir", "V neeck Thsirt", 0, 700, 4, 1111);
    var itemE: Items = Items("Wrogn", "Printed Rounded neck", 0, 850, 4, 1111);

    init {
        itemList.add(0, itemA)
        itemList.add(1, itemB)
        itemList.add(2, itemC)
        itemList.add(3, itemD)
        itemList.add(4, itemE)
    }

    val likes: LiveData<Int> = _likes

    val popularity: LiveData<Popularity> = Transformations.map(_likes) {
        when {
            it > 9 -> Popularity.STAR
            it > 4 -> Popularity.POPULAR
            else -> Popularity.NORMAL
        }
    }

    fun onLike() {
        _likes.value = (_likes.value ?: 0) + 1
    }

    enum class Popularity {
        NORMAL,
        POPULAR,
        STAR
    }
}